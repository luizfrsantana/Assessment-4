const express = require('express');
const Recipe = require('../models/Recipe');
const router = express.Router();

// Search recipes by title, ingredients, or tags
router.get('/search', async (req, res) => {
    const { searchQuery } = req.query;
    try {
        const recipes = await Recipe.find({
            $or: [
                { title: { $regex: searchQuery, $options: 'i' } },
                { ingredients: { $regex: searchQuery, $options: 'i' } },
                { tags: { $regex: searchQuery, $options: 'i' } }
            ]
        });
        res.json(recipes);
    } catch (error) {
        res.status(500).json({ message: 'Error searching recipes' });
    }
});

// Filter recipes by category
router.get('/filter', async (req, res) => {
    const { category } = req.query;
    try {
        const recipes = await Recipe.find({ category });
        res.json(recipes);
    } catch (error) {
        res.status(500).json({ message: 'Error filtering recipes' });
    }
});

module.exports = router;

// Post a rating
router.post('/:id/rate', async (req, res) => {
    const { rating } = req.body;
    try {
        const recipe = await Recipe.findById(req.params.id);
        recipe.ratings.push({ user: req.user._id, rating });
        await recipe.save();
        res.json({ message: 'Rating added successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Error adding rating' });
    }
});
// Post a comment
router.post('/:id/comment', async (req, res) => {
    const { comment } = req.body;
    try {
        const recipe = await Recipe.findById(req.params.id);
        recipe.comments.push({ user: req.user._id, comment: comment });
        await recipe.save();
        res.json({ message: 'Comment added successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Error adding comment' });
    }
});

// Get ratings and comments for a recipe
router.get('/:id/ratings-comments', async (req, res) => {
    try {
        const recipe = await Recipe.findById(req.params.id).populate('ratings.user comments.user', 'username');
        res.json({
            ratings: recipe.ratings,
            comments: recipe.comments
        });
    } catch (error) {
        res.status(500).json({ message: 'Error retrieving ratings and comments' });
    }
});
const { isLoggedIn } = require('../middlewares/authMiddleware');

// Route to post a rating to a recipe
router.post('/:id/rate', isLoggedIn, async (req, res) => {
    const { rating } = req.body;
    try {
        const recipe = await Recipe.findById(req.params.id);
        recipe.ratings.push({ user: req.user._id, rating });
        await recipe.save();
        res.json({ message: 'Rating added successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Error adding rating' });
    }
});

// Route to post a comment to a recipe
router.post('/:id/comment', isLoggedIn, async (req, res) => {
    const { comment } = req.body;
    try {
        const recipe = await Recipe.findById(req.params.id);
        recipe.comments.push({ user: req.user._id, comment });
        await recipe.save();
        res.json({ message: 'Comment added successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Error adding comment' });
    }
});
