const mongoose = require('mongoose');

const recipeSchema = new mongoose.Schema({
    title: String,
    ingredients: [String],
    instructions: String,
    category: String,
    tags: [String],
    creator: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    }
});
const Recipe = mongoose.model('Recipe', recipeSchema);
module.exports = Recipe;

recipeSchema.add({
    ratings: [{ user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, rating: Number }],
    comments: [{ user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, comment: String }]
});
