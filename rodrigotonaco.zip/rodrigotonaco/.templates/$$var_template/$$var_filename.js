export default function $$var_textInFile() {
}
